# Phase 2 Implementation Record

## Scope and Status

This extends the existing React/Three.js Phase 1 game. The vehicle controller,
articulated trailer, cargo state machine, parking outcomes, economy, weather,
navigation and event identifiers remain in place. It is not a replacement game.

The production build has been run successfully during implementation. The available
tools do not provide an interactive browser, audio output or a gameplay automation
runner. No visual acceptance pass, listening test, FPS baseline, browser persistence
restart or complete driving session is claimed here. **Phase 2 runtime acceptance
is pending.** The user's Phase 1 runtime acceptance remains the baseline, not evidence
that the changes below have passed the new runtime tests.

## Acceptance Remediation Pass

The requested remediation pass adds no gameplay subsystems:

- The existing `REdge.routeCode` metadata now creates physical roadside route-number
  markers. D.100 uses the existing `M.signHwy` texture; D.180, D.795, D.850 and D.200
  use route-shield textures. The existing rest-area entrance now places `M.signP`.
- Yalıboyu is ordered west-to-east as city-side timber houses at x=20, the riverfront
  road centred near x=38, a pedestrian promenade at x=56 and the Yeşilırmak west bank
  around x=68-77 along this reach. The river definition has not moved.
- Two-edge road-mouth trimming now meets its matching fillet at radius `n.R`; the
  previous extra two-metre cut could exceed that fillet. The riverfront connectors
  terminate at H2 and SB0, so those bridge-adjacent junctions share the same mouth
  boundary triangulation as the rest of the graph.
- Every bridge deck top now uses the same `groundHeight + 0.10` surface rule as the
  road mesh; underside, parapets and piers are built relative to that height. River
  water follows the same regional base elevation. The deck is not an absolute-world-Y
  slab any more.
- Çorum has one small fenced unfinished frame with columns, beams, material pallets,
  a container, barrels, collision boundaries and a `tr.construction` warning board.
  The existing Çorum shopfront uses `tr.shopTire`; `tr.yield` is rendered on the give-way
  sign and `tr.cityCenter` is interpolated into the Amasya city board.
- `validatePhase2()` returns machine-readable `missingReferences`, `missingCities`,
  `missingLocations`, `missingRoadConnections`, `missingEventHooks`, localization
  results, save-schema results and `runtimeAcceptance: NOT_RUN`. The F3 console hook
  prints the full report. It is structural and in-memory only; it does not run a drive
  or claim browser acceptance. This headless session did not execute the helper.
- The job board's route memoization was reviewed: it calculates one pickup route per
  distinct origin when opened. The game is paused behind the job modal, so the vehicle
  cannot move while these displayed values are in use. No navigation rewrite was made.

## Implemented Region

- Amasya: the original starting depot and local delivery loop, Turkish urban shops,
  a connected riverside street, timber-fronted houses, river bridges, mosques,
  valley ridges, an orchard and agricultural outskirts.
- Tokat: a compact connected town and logistics delivery yard.
- Çorum: a compact connected town and machinery dispatch yard.
- Samsun: a compact distribution district and town, not a full recreation of the city.
- Sivas: a plateau settlement and industrial delivery yard.
- Yozgat: a plateau settlement, grain silos and cooperative delivery yard.
- Each added settlement has a working pump and garage registered with the original
  service interactions, plus a rest area and urban street loop.
- Twelve contracts, including the five original local contract IDs, now use built
  Turkish locations. Produce crates, grain sacks and textile bales extend the
  existing three cargo/loading families rather than replacing loading logic.

The map is deliberately compressed (roughly 4.4 by 4.0 world kilometres). Displayed
distance is measured along the game road graph. It is not a claim that the real cities
are this close together. Names, bearings and D.100/D.180/D.795/D.850/D.200 corridor
relationships are geographically inspired, not a surveyed navigation product.

Reference material consulted:

- https://www.kgm.gov.tr/Sayfalar/KGM/SiteTr/Root/Haritalarr.aspx
- https://wiki.aaroads.com/wiki/List_of_highways_in_Turkey

## Data and Extension Points

`src/game/regions.ts` defines provinces, cities, districts, village metadata,
industries, stable cargo site IDs, service IDs, road corridors and contracts.
`src/game/regionalWorld.ts` attaches these to the existing `RoadGraph` and reusable
building/prop builders. `World.locations` retains the original six IDs for compatibility.

To add a future province: add its province record, actual cargo site name, corridor
definitions and contracts referencing that built site; adjust data bounds as needed.
The settlement builder produces its street loop, yard, services and props. This does
not require changes to truck physics, cargo transfer, routing or save identifiers.

## Presentation and Geometry

- `src/game/i18n.ts` is the Turkish player-facing text and number-formatting layer.
  It covers start/menu/HUD text, job descriptions, prompts, notifications, errors,
  settings, parking results, diagnostics labels, dashboard labels and signage.
- Currency is displayed using the Turkish lira symbol and `tr-TR` formatting. Existing
  numeric balances are not converted or reset. Fuel and service prices remain the
  established fictional game economy, not real-world Turkish retail prices.
- State-road direction signs use blue backgrounds; settlement/local signs use light
  backgrounds. Roadsign UVs now show the whole sign instead of a cropped quarter.
- `roadSurface.ts` trims roads at their junction mouths and triangulates the intervening
  surface using the exact mouth coordinates. The old overlapping junction discs are
  no longer drawn. Textures use shared world-space UVs, approach widths taper, and
  highway rails/refuges follow the elevation field as continuous swept geometry.
- `elevation.ts` supplies the same height field to terrain, road meshes, vehicles,
  cargo and cameras. The tested core depot is still level. Elevation support is an
  extension of the planar vehicle controller, not a new rigid-body simulation.
- Cab eye position is `(0.55, 2.61, 3.06)`: raised and moved back to clear the cowl and
  keep the instruments/wheel below the road view. Numpad height and hold-to-look
  controls remain. Reduced glass tint avoids multiple dark, double-sided layers.
- The existing Web Audio module now uses a bounded harmonic diesel waveform, changing
  low/mid/high-RPM layer gains, load/coasting/engine-braking response, gear-change
  unloading, a subdued turbo layer, brake air release and output compression.
  It is procedural synthesis; no claim of recorded-engine realism or a listening
  test is made.

## Save and Event Compatibility

`profile.ts` reads `nordhaul_p1_save` v1 and migrates the older `nordhaul_p1` key.
Money, XP, level, ownership and the restored truck ID are preserved. A previous valid
save is backed up before writing. Migration write failures do not discard readable
progression. The v1 schema is retained with additive world/locale metadata. Reloading
does not restore an active cargo job, position, fuel or damage; that is unchanged
from the Phase 1 persistence scope. A real browser reload test is still required.

All existing gameplay event names remain English and unchanged. In particular:
`PLAYER_CRASHED`, `DELIVERY_COMPLETED`, `DELIVERY_FAILED`, `FUEL_LOW`, `FUEL_EMPTY`,
`PARKING_SUCCESS`, `PARKING_FAILED`, `NEW_LOCATION_DISCOVERED`, `TRAFFIC_ACCIDENT`,
and `WEATHER_CHANGED`. The F3 UI displays localized labels, not renamed hooks.

## Performance and Checks

- Existing batching and instancing are reused. Terrain is divided into independently
  culled chunks; foliage is instanced. This is visibility culling, not network/disk streaming.
- The traffic pool remains bounded at 24 vehicles and adds buses/minibuses to existing
  cars, vans and trucks. Additional static obstacle probes reduce building penetration.
- The F3 panel counts the whole render frame (including mirrors and postprocessing),
  rather than only the final fullscreen pass. FPS uses actual, unclamped elapsed time.
- Finished/cancelled cargo geometry is disposed without disposing shared materials.
- Job-board pickup routes are cached while the menu is open instead of recalculated
  on every HUD refresh.
- No FPS or target-hardware performance figure has been fabricated.

In a running game, `window.__validatePhase2()` runs read-only structural checks:
directed connectivity in both directions, spline endpoints, service/site references,
job routes, accurate/poor parking geometry, in-memory legacy/v1 serialization tests,
finite elevations and sampled static lane clearances. It does **not** teleport or
drive the player, award money, alter real saves, or claim to be an end-to-end test.
It explicitly returns `scope: STRUCTURAL_ONLY` and `runtimeAcceptance: NOT_RUN`.
The helper was implemented and bundled; it was not executed with the available tools.

## Required Runtime Recheck

1. Load an existing v1 save and record money, XP, level, ownership and truck ID.
2. Start in Amasya, enter with F, switch cab/exterior with C, check steering, brakes,
   reverse, gears, wheels, suspension, trailer, mirrors and Numpad camera controls.
3. Complete one original local job, then an Amasya-to-Tokat or Amasya-to-Samsun contract.
   Drive normally; do not use recovery/teleportation as evidence of route reachability.
4. Inspect the west exit, riverside joins, roundabout, village/farm link, new city
   junctions and plateau bridge from both cameras. Check road/rail/terrain continuity.
5. Confirm accurate and poor parking, then contact during a manoeuvre. Contact must
   cap the result at 52 and also cap its reward multiplier, not just its displayed grade.
6. Refuel at both the original station and an added city pump. Verify litres, debit,
   fuel-low/empty events and matching HUD/dashboard readings.
7. Cause a controlled collision, repair at a new garage, verify damage decrease and debit.
8. Drive through traffic-light junctions and watch all vehicle categories. Check for
   queue deadlocks, incorrect turns, building collisions and road departures.
9. Test clear/rain/clear and day/sunset/night; verify wipers, visibility, road wetness,
   headlights, lit signs/windows and streetlights on elevated roads.
10. Listen at idle, under load, through shifts, while coasting and braking. Check
    relative loudness, missing audio, clipping, excessive bass and pure-tone artifacts.
11. Complete a ten-minute uninterrupted session. Record browser/OS/GPU, render size,
    FPS/frame time and draw calls from F3. Inspect repeated console errors.
12. Reload after changing money/XP. Verify both progression and the same truck ID.

## Known Limits and Deferred Work

- The added cities are representative compact districts, not full cities or exact maps.
- Runtime road clearances, camera comfort, AI turning/queues, night/rain appearance,
  audio quality and ten-minute stability have not been observed in this environment.
- The original traffic controller is intentionally simple. It is not a sophisticated
  Turkish driver behaviour simulation; long buses and narrow corners need road testing.
- Large decorative ridges use coarse static collision bounds. Off-road terrain handling
  remains simplified; the controller has no full vertical rigid-body dynamics.
- Nationwide expansion, detailed ports, on-demand region streaming, additional trucks,
  live-stream UI/KICK/chat/donations, multiplayer and company/fleet systems are not built.

Implementation delivered; **do not mark Phase 2 fully accepted until the runtime
recheck above succeeds.**